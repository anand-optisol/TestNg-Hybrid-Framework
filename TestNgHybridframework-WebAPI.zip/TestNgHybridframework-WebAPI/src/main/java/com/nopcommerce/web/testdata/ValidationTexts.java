package com.nopcommerce.web.testdata;

public class ValidationTexts {

	//Register
	public static String registerCompletedMessage = "Your registration completed";

}
